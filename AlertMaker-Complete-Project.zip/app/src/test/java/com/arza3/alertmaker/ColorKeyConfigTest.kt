package com.arza3.alertmaker

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ColorKeyConfigTest {
    @Test fun acceptsSixDigitHexWithOrWithoutHash() {
        assertEquals("000000", ColorKeyConfig.normalizeHex("#000000"))
        assertEquals("FF00AA", ColorKeyConfig.normalizeHex("ff00aa"))
    }
    @Test fun rejectsInvalidHex() {
        assertNull(ColorKeyConfig.normalizeHex("#FFF"))
        assertNull(ColorKeyConfig.normalizeHex("#GG0000"))
        assertNull(ColorKeyConfig.normalizeHex(""))
    }
}
