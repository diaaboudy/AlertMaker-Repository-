# AlertMaker — Android video transparency exporter

Native Android app (Kotlin + Jetpack Compose + Material 3) for keying a selected RGB color out of a video on-device and exporting transparent media.

## Current implementation

- Android document picker (`OpenDocument`) for local video selection; input is copied from the `content://` stream into the app cache before FFmpeg runs.
- Arabic RTL dark UI; displays filename, duration and resolution; plays the original video preview.
- User-entered six-digit Hex key color (default `#000000`), Similarity and Blend controls.
- WorkManager long-running foreground work, progress from FFmpeg statistics/log timestamps, elapsed/estimated remaining time, and cancellation.
- WebM VP9 (`libvpx-vp9`, `yuva420p`, `-auto-alt-ref 0`, `alpha_mode=1`, Opus audio when requested).
- MOV ProRes 4444 (`prores_ks`, `yuva444p10le`, PCM audio when requested).
- PNG image sequence with passthrough frame timing and no audio.
- Saves WebM/MOV under `Movies/AlertMaker/...`; PNG frames under `Movies/AlertMaker/PNG Sequence/<job>/` on Android 10+.
- Extracts an actual frame from the processed output and checks its decoded PNG alpha values; export is reported successful only if the preview contains both transparent and visible sampled pixels.
- Runtime encoder preflight (`-h encoder=...`) fails with a clear message if a required encoder is missing.
- LGPL and third-party notices bundled in app assets and `licenses/`.

## FFmpeg dependency and codec scope

The project pins the community-maintained Android FFmpegKit continuation:

```kotlin
implementation("dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.7")
```

The maintainer publishes the `ffmpeg-kit-full` 8.1 LTS LGPL artifact on Maven Central and documents `libvpx` in its video tier (included by `full`). The project uses a runtime encoder preflight for `libvpx-vp9`, `prores_ks`, and `png`; a missing encoder is reported instead of silently substituting another format. ProRes is an FFmpeg-native encoder; its presence is still checked on the actual installed binary at runtime. The upstream package matrix and license are documented at https://github.com/ffmpegkit-maintained/ffmpeg.

The app does **not** upload user videos to a server. FFmpeg runs locally on the device. Large/high-resolution files may require substantial free storage, RAM, battery and processing time.

## Build locally

Requirements: JDK 17 and Android SDK platform 35 / build-tools 35.0.0.

```bash
chmod +x ./gradlew
./gradlew testDebugUnitTest assembleDebug
```

APK output:

`app/build/outputs/apk/debug/app-debug.apk`

The included `gradlew` bootstrap script downloads the pinned Gradle 8.9 distribution on first run; no separately installed Gradle is needed. Android SDK is still required for a local build.

## Build on GitHub Actions

### Easiest route when uploading from a phone

The ZIP contains a helper workflow at `.github/workflows/unpack-alertmaker.yml`. GitHub does not automatically unpack a ZIP uploaded as a normal repository file, so do this once:

1. Add the helper workflow file to your repository at the exact path `.github/workflows/unpack-alertmaker.yml` (GitHub → Add file → Create new file; copy the file contents from this ZIP), then commit it.
2. Upload `AlertMaker-Complete-Project.zip` to the repository root and commit it.
3. Open **Actions** → **Unpack AlertMaker project ZIP** → **Run workflow**. It extracts the project files into the repository and commits them. The archive is then removed from the repository.
4. That commit triggers **Build AlertMaker Android APK** automatically.
5. Open the successful build run and download the `AlertMaker-debug-apk` artifact.

Alternatively, extract the ZIP locally and upload all its contents directly into the repository root. Do not leave the project nested inside an extra `AlertMakerFull/` folder.

The build workflow configures JDK 17 and Android SDK 35, runs unit tests, builds `assembleDebug`, and uploads the APK.

## Install on Android

Download and extract the workflow artifact, open `app-debug.apk` on the phone, and allow installation from the browser/file manager if Android asks. This is a debug-signed APK intended for testing, not a Play Store release.

## Alpha verification and practical testing

The app does not equate a checkerboard background with transparency. It extracts a PNG from the encoded output, decodes the frame, samples alpha values, and only marks the job successful if it finds both transparent and visible pixels. For WebM it explicitly selects `libvpx-vp9` as the decoder before the input: FFmpeg's native VP9 decoder can drop WebM's separate alpha side data and otherwise make a valid transparent file appear opaque. This verifies the processed preview frame, not every frame of the full video. If the first frame contains no visible foreground, try a clip whose subject is visible near the beginning.

Suggested manual test:

1. Create a 3–5 second test clip with a pure black background, a bright opaque square/person in the center, and audio.
2. Export WebM, MOV, and PNG Sequence separately.
3. Inspect the generated preview: the black area should show checkerboard and the subject should remain visible.
4. For WebM, use a current FFmpeg/FFprobe build to inspect the `ALPHA_MODE=1` stream tag, then decode with `ffmpeg -c:v libvpx-vp9 -i output.webm -vf alphaextract -frames:v 1 alpha.png`; verify the alpha image has black/gray transparent areas and white opaque foreground. Do not rely on the native VP9 decoder for this check. For MOV, check `pix_fmt=yuva444p10le` and decode a frame. For PNG Sequence, inspect one frame in an image editor that shows transparency.
5. In OBS, add the WebM as a **Media Source** and place it over gameplay; do not apply a green-screen/chroma-key filter.

OBS support for VP9 WebM alpha is generally useful for this workflow, but compatibility with every version of TikTok LIVE Studio, every playback path, and every capture setup is not guaranteed. Test the exported file in the exact version you use. MOV/ProRes support also varies by software.

## Known limits (not hidden)

- This is a color-key tool, not AI segmentation. It works best with a flat, evenly lit background; similar colors in the subject may also become transparent, and shadows/compression noise can leave halos.
- The Hex color field is implemented. A tap-to-sample color picker from an arbitrary video frame is not included in this build.
- The post-export alpha check examines a real decoded preview frame, not every frame in the video. It cannot guarantee that every frame has a useful foreground/background separation.
- PNG sequence can create thousands of files; storage exhaustion is reported by the worker. It does not package the frames into a ZIP.
- On Android 10+ output uses MediaStore `RELATIVE_PATH`. On Android 8/9, the compatibility fallback is app-specific external Movies storage because modern scoped MediaStore paths are unavailable; files may not appear in the public Movies folder automatically.
- GitHub Actions builds are configured but were not executed in this environment; no APK build result is claimed here.

## Licenses

The app source is MIT-licensed (see `LICENSE`). The FFmpegKit Android dependency is LGPL-3.0; FFmpeg components and third-party libraries retain their respective licenses. See `licenses/LGPL-3.0.txt`, `licenses/LGPL-2.1.txt`, `licenses/FFMPEG-THIRD-PARTY-NOTICES.txt`, and the bundled `app/src/main/assets/` copies. Review the dependency's current license and source obligations before redistributing modified binaries.
