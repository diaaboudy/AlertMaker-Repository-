@echo off
setlocal
set GRADLE_VERSION=8.9
set DIST=%USERPROFILE%\.gradle\wrapper\dists\gradle-%GRADLE_VERSION%-bin\alertmaker
set GRADLE=%DIST%\gradle-%GRADLE_VERSION%\bin\gradle.bat
if not exist "%GRADLE%" (
  if not exist "%DIST%" mkdir "%DIST%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%DIST%\gradle.zip'; Expand-Archive -Force '%DIST%\gradle.zip' '%DIST%'; Remove-Item '%DIST%\gradle.zip'"
)
call "%GRADLE%" -p "%~dp0" %*
