package com.arza3.alertmaker

import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.runtime.livedata.observeAsState
import androidx.work.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(11, 13, 22)
        window.navigationBarColor = android.graphics.Color.rgb(11, 13, 22)
        setContent { AlertMakerApp() }
    }
}

@Composable
private fun AlertMakerApp() {
    val context = LocalContext.current
    val workManager = remember { WorkManager.getInstance(context) }
    var inputUri by remember { mutableStateOf<Uri?>(null) }
    var displayName by remember { mutableStateOf("") }
    var fileDetails by remember { mutableStateOf("") }
    var format by remember { mutableStateOf("WEBM") }
    var colorHex by remember { mutableStateOf("#000000") }
    var similarity by remember { mutableFloatStateOf(0.15f) }
    var blend by remember { mutableFloatStateOf(0.08f) }
    var crf by remember { mutableIntStateOf(32) }
    var cpu by remember { mutableIntStateOf(4) }
    var keepAudio by remember { mutableStateOf(true) }
    var workId by remember { mutableStateOf<UUID?>(null) }
    var showLicenses by remember { mutableStateOf(false) }
    val emptyWorkInfoState = remember { mutableStateOf<WorkInfo?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            inputUri = uri
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            displayName = queryName(context, uri) ?: "video"
            val bytes = querySize(context, uri)
            fileDetails = readVideoDetails(context, uri) + if (bytes > 0) " • ${formatBytes(bytes)}" else ""
        }
    }
    val currentWorkLiveData = remember(workId) { workId?.let { workManager.getWorkInfoByIdLiveData(it) } }
    val workInfoState = currentWorkLiveData?.observeAsState() ?: emptyWorkInfoState
    val workInfo by workInfoState

    val outputUri = workInfo?.outputData?.getString(ExportWorker.KEY_OUTPUT_URI)?.let(Uri::parse)
    val previewPath = workInfo?.outputData?.getString(ExportWorker.KEY_PREVIEW_PATH)
    val errorMessage = workInfo?.outputData?.getString(ExportWorker.KEY_ERROR)
    val technicalError = workInfo?.outputData?.getString(ExportWorker.KEY_TECHNICAL)
    val progress = workInfo?.progress?.getInt(ExportWorker.KEY_PROGRESS, 0) ?: 0
    val isRunning = workInfo?.state == WorkInfo.State.RUNNING || workInfo?.state == WorkInfo.State.ENQUEUED
    val isDone = workInfo?.state == WorkInfo.State.SUCCEEDED
    val isFailed = workInfo?.state == WorkInfo.State.FAILED
    val isCancelled = workInfo?.state == WorkInfo.State.CANCELLED

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF9B8CFF), secondary = Color(0xFF35D6B3),
        background = Color(0xFF0B0D16), surface = Color(0xFF171B2A)
    )) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Column(
                Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0B0D16), Color(0xFF17172B))))
                    .verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("ALERT MAKER", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
                    Text("حوّل فيديوهات التنبيهات إلى ملفات شفافة حقيقية", color = Color(0xFFB4BCD0), fontSize = 13.sp)
                }
                SectionCard("١. اختيار الفيديو") {
                    Button(onClick = { picker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null)
                        Spacer(Modifier.width(8.dp)); Text(if (inputUri == null) "اختيار فيديو من الهاتف" else "اختيار فيديو آخر")
                    }
                    if (inputUri != null) {
                        Text(displayName, color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(fileDetails, color = Color(0xFFADB7CB), fontSize = 12.sp)
                        AndroidView(
                            factory = { ctx -> VideoView(ctx).apply { setVideoURI(inputUri); setOnPreparedListener { it.isLooping = true; it.setVolume(0f, 0f); start() } } },
                            update = { view -> if (view.tag != inputUri) { view.tag = inputUri; view.setVideoURI(inputUri); view.setOnPreparedListener { it.isLooping = true; it.setVolume(0f, 0f); it.start() } } },
                            modifier = Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(12.dp)).background(Color.Black)
                        )
                    } else Text("لم يتم اختيار فيديو بعد", color = Color(0xFF9DA8BD), fontSize = 13.sp)
                }

                SectionCard("٢. لون الخلفية المراد حذفه") {
                    OutlinedTextField(
                        value = colorHex, onValueChange = { colorHex = it.uppercase(Locale.US).take(7) },
                        label = { Text("لون Hex مثل #000000") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        supportingText = { Text("الافتراضي أسود. أدخل 6 خانات Hex بعد علامة #.") }
                    )
                    SliderSetting("قوة إزالة اللون (Similarity)", similarity, "%.2f".format(similarity), 0f..1f) { similarity = it }
                    SliderSetting("نعومة انتقال الحواف (Blend)", blend, "%.2f".format(blend), 0f..1f) { blend = it }
                    Text("Similarity يحدد مدى الألوان القريبة من لون المفتاح التي تصبح شفافة. Blend ينعّم حافة الانتقال فقط. الخلفيات المعقدة أو المتحركة قد تحتاج أدوات عزل متقدمة.", color = Color(0xFF9DA8BD), fontSize = 11.sp)
                }

                SectionCard("٣. صيغة التصدير") {
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                        listOf("WEBM" to "WebM VP9", "MOV" to "MOV ProRes", "PNG" to "PNG Sequence").forEach { (value, label) ->
                            FilterChip(selected = format == value, onClick = { format = value }, label = { Text(label, fontSize = 11.sp) })
                        }
                    }
                    if (format == "WEBM") {
                        SliderSetting("جودة VP9 — CRF", crf.toFloat(), crf.toString(), 18f..50f, steps = 31) { crf = it.toInt() }
                        SliderSetting("سرعة المعالج — cpu-used", cpu.toFloat(), cpu.toString(), 0f..8f, steps = 7) { cpu = it.toInt() }
                        Text("CRF الأقل يعطي جودة أعلى وحجمًا أكبر. cpu-used الأعلى أسرع عادةً وقد يقلل الكفاءة.", color = Color(0xFF9DA8BD), fontSize = 11.sp)
                    } else if (format == "MOV") {
                        Text("ProRes 4444 يحفظ Alpha بجودة عالية، لكنه قد ينتج ملفات كبيرة. CRF لا ينطبق على هذا الترميز.", color = Color(0xFF9DA8BD), fontSize = 12.sp)
                    } else {
                        Text("سيتم حفظ كل إطار كصورة PNG مستقلة مع Alpha. لا يوجد صوت في PNG Sequence، ومعدل الإطارات الأصلي محفوظ دون إسقاط مقصود.", color = Color(0xFF9DA8BD), fontSize = 12.sp)
                    }
                    if (format != "PNG") {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = keepAudio, onCheckedChange = { keepAudio = it })
                            Text("الاحتفاظ بالصوت إذا كان موجودًا", color = Color.White, fontSize = 13.sp)
                        }
                    }
                }

                SectionCard("٤. التصدير والتحقق") {
                    Button(
                        onClick = {
                            val normalized = ColorKeyConfig.normalizeHex(colorHex) ?: ""
                            if (normalized.matches(Regex("[0-9A-Fa-f]{6}")) && inputUri != null) {
                                val request = OneTimeWorkRequestBuilder<ExportWorker>()
                                    .setInputData(workDataOf(
                                        ExportWorker.KEY_URI to inputUri.toString(), ExportWorker.KEY_FORMAT to format,
                                        ExportWorker.KEY_COLOR to normalized, ExportWorker.KEY_SIMILARITY to similarity,
                                        ExportWorker.KEY_BLEND to blend, ExportWorker.KEY_CRF to crf,
                                        ExportWorker.KEY_CPU to cpu, ExportWorker.KEY_AUDIO to keepAudio
                                    ))
                                    .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
                                    .build()
                                workId = request.id
                                workManager.enqueue(request)
                            }
                        }, enabled = inputUri != null && !isRunning && ColorKeyConfig.normalizeHex(colorHex) != null,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("إزالة الخلفية وتصدير ${formatLabel(format)}") }

                    if (isRunning) {
                        LinearProgressIndicator(progress = progress / 100f, modifier = Modifier.fillMaxWidth())
                        val elapsed = workInfo?.progress?.getInt(ExportWorker.KEY_ELAPSED, 0) ?: 0
                        val eta = workInfo?.progress?.getInt(ExportWorker.KEY_ETA, -1) ?: -1
                        Text("${workInfo?.progress?.getString(ExportWorker.KEY_STATUS) ?: "جارٍ التحضير"} — $progress%", color = Color(0xFFB9C4D8), fontSize = 12.sp)
                        Text("الوقت المنقضي: ${elapsed}ث • المتبقي: ${if (eta >= 0) "نحو ${eta}ث" else "جارٍ الحساب"}", color = Color(0xFF9DA8BD), fontSize = 11.sp)
                        OutlinedButton(onClick = { workId?.let(workManager::cancelWorkById) }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.StopCircle, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("إلغاء التصدير")
                        }
                    }
                    if (isDone && outputUri != null) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, tint = Color(0xFF35D6B3), contentDescription = null)
                            Spacer(Modifier.width(6.dp)); Text("اكتمل التصدير والتحقق من قناة Alpha.", color = Color(0xFF35D6B3))
                        }
                        Text("تم الحفظ: $outputUri", color = Color(0xFFB9C4D8), fontSize = 11.sp)
                        if (format == "PNG") Text("عدد الصور: ${workInfo?.outputData?.getInt(ExportWorker.KEY_OUTPUT_COUNT, 0) ?: 0}", color = Color.White)
                        Button(onClick = { shareOutput(context, outputUri, if (format == "PNG") "image/png" else if (format == "WEBM") "video/webm" else "video/quicktime") }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Share, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("مشاركة / فتح الملف")
                        }
                        if (previewPath != null) ProcessedPreview(previewPath)
                    }
                    if (isFailed) {
                        Text(errorMessage ?: "فشل التصدير.", color = Color(0xFFFF9999), fontSize = 13.sp)
                        if (!technicalError.isNullOrBlank()) Text("تفاصيل تقنية: $technicalError", color = Color(0xFF9DA8BD), fontSize = 10.sp)
                    }
                    if (isCancelled) Text("تم إلغاء التصدير.", color = Color(0xFFFFC46B))
                    Text("الملفات تُعالج محليًا على هاتفك ولا تُرفع إلى خادم.", color = Color(0xFF8D98AF), fontSize = 11.sp)
                }
                TextButton(onClick = { showLicenses = true }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("التراخيص ومكتبات الطرف الثالث", color = Color(0xFF9B8CFF), fontSize = 11.sp) }
                Text("AlertMaker • TikTok Live & OBS", color = Color(0xFF68748D), fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
    if (showLicenses) {
        val notices = remember { try { context.assets.open("THIRD-PARTY-NOTICES.txt").bufferedReader().use { it.readText() } } catch (_: Exception) { "تعذّر تحميل إشعارات التراخيص." } }
        AlertDialog(onDismissRequest = { showLicenses = false }, confirmButton = { TextButton(onClick = { showLicenses = false }) { Text("إغلاق") } }, title = { Text("التراخيص") }, text = { Text(notices, fontSize = 11.sp) })
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xE6171B2A)), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            content()
        }
    }
}

@Composable
private fun SliderSetting(label: String, value: Float, valueLabel: String, range: ClosedFloatingPointRange<Float>, steps: Int = 0, onChange: (Float) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Color(0xFFE4E8F2), fontSize = 13.sp)
            Text(valueLabel, color = Color(0xFFB8ABFF), fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range, steps = steps)
    }
}

@Composable
private fun ProcessedPreview(path: String) {
    val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, path) {
        value = withContext(Dispatchers.IO) { try { android.graphics.BitmapFactory.decodeFile(path) } catch (_: Exception) { null } }
    }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("معاينة الإطار بعد المعالجة (PNG فعلي بقناة Alpha)", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Box(Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(12.dp))) {
            Checkerboard(Modifier.fillMaxSize())
            if (bitmap != null) androidx.compose.foundation.Image(bitmap!!.asImageBitmap(), contentDescription = "معاينة شفافية الفيديو", modifier = Modifier.fillMaxSize())
        }
    }
}

@Composable
private fun Checkerboard(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val cell = 18.dp.toPx(); val a = Color(0xFFE0E0E0); val b = Color(0xFF8B8B8B)
        var y = 0f; var row = 0
        while (y < size.height) {
            var x = 0f; var col = 0
            while (x < size.width) {
                drawRect(if ((row + col) % 2 == 0) a else b, androidx.compose.ui.geometry.Offset(x, y), androidx.compose.ui.geometry.Size(cell, cell))
                x += cell; col++
            }
            y += cell; row++
        }
    }
}

private fun queryName(context: android.content.Context, uri: Uri): String? = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }

private fun querySize(context: android.content.Context, uri: Uri): Long = context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { if (it.moveToFirst()) it.getLong(0) else 0L } ?: 0L

private fun formatBytes(bytes: Long): String = when {
    bytes >= 1024L * 1024 * 1024 -> "%.2f GB".format(bytes / (1024.0 * 1024 * 1024))
    bytes >= 1024L * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
    else -> "${bytes / 1024} KB"
}

private fun readVideoDetails(context: android.content.Context, uri: Uri): String = try {
    val retriever = MediaMetadataRetriever()
    try {
        retriever.setDataSource(context, uri)
        val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH) ?: "?"
        val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT) ?: "?"
        val minutes = duration / 60000; val seconds = (duration / 1000) % 60
        "$width × $height • %02d:%02d".format(minutes, seconds)
    } finally { retriever.release() }
} catch (_: Exception) { "تعذّر قراءة بيانات الفيديو" }

private fun formatLabel(value: String) = when (value) { "WEBM" -> "WebM"; "MOV" -> "MOV"; else -> "PNG Sequence" }

private fun shareOutput(context: android.content.Context, uri: Uri, mime: String) {
    val intent = Intent(Intent.ACTION_SEND).apply { type = mime; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
    context.startActivity(Intent.createChooser(intent, "فتح أو مشاركة الناتج"))
}
