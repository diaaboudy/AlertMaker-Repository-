package com.arza3.alertmaker

object ColorKeyConfig {
    fun normalizeHex(value: String): String? {
        val normalized = value.trim().removePrefix("#")
        return normalized.takeIf { it.matches(Regex("^[0-9A-Fa-f]{6}$")) }?.uppercase()
    }
}
