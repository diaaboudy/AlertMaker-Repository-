#!/usr/bin/env sh
# Requires a desktop FFmpeg build. Produces a 4-second MP4 test source with a black background and a moving white square.
set -eu
ffmpeg -y -f lavfi -i "color=c=black:s=640x360:r=30:d=4" \
  -vf "drawbox=x='40+120*t':y=110:w=140:h=140:color=white:t=fill" \
  -c:v libx264 -pix_fmt yuv420p -an alertmaker-alpha-test.mp4
printf 'Created alertmaker-alpha-test.mp4\n'
