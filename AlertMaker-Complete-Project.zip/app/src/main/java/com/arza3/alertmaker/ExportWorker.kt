package com.arza3.alertmaker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

class ExportWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    private val notificationId = 4107
    private val channelId = "alertmaker_export"
    private val activeSession = AtomicLong(-1L)
    private val lastProgress = AtomicInteger(0)

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val inputText = inputData.getString(KEY_URI) ?: return@withContext Result.failure(workDataOf(KEY_ERROR to "لم يتم تحديد ملف الفيديو."))
        val uri = Uri.parse(inputText)
        val format = inputData.getString(KEY_FORMAT) ?: "WEBM"
        val key = inputData.getString(KEY_COLOR) ?: "000000"
        val similarity = inputData.getFloat(KEY_SIMILARITY, 0.15f).coerceIn(0f, 1f)
        val blend = inputData.getFloat(KEY_BLEND, 0.08f).coerceIn(0f, 1f)
        val crf = inputData.getInt(KEY_CRF, 32).coerceIn(18, 50)
        val cpu = inputData.getInt(KEY_CPU, 4).coerceIn(0, 8)
        val keepAudio = inputData.getBoolean(KEY_AUDIO, true)
        val workDir = File(applicationContext.cacheDir, "alertmaker_${id}").apply { mkdirs() }
        val source = File(workDir, "source_video")
        val preview = File(applicationContext.cacheDir, "alertmaker_preview_${id}.png")
        try {
            setForeground(createForeground("جارٍ تجهيز الفيديو", 0))
            applicationContext.contentResolver.openInputStream(uri)?.use { stream ->
                FileOutputStream(source).use { out -> stream.copyTo(out) }
            } ?: return@withContext fail("تعذّرت قراءة الفيديو. اختر الملف مرة أخرى.")
            if (!source.exists() || source.length() < 1024) return@withContext fail("ملف الفيديو فارغ أو غير صالح.")
            val availableBytes = StatFs(applicationContext.cacheDir.absolutePath).availableBytes
            if (availableBytes < 100L * 1024 * 1024) return@withContext fail("المساحة الحرة غير كافية. وفر 100 ميجابايت على الأقل ثم أعد المحاولة.")
            val durationMs = readDuration(source)
            val outputDir = File(workDir, "out").apply { mkdirs() }
            val base = "AlertMaker_${System.currentTimeMillis()}"
            val output = when (format) {
                "WEBM" -> File(outputDir, "$base.webm")
                "MOV" -> File(outputDir, "$base.mov")
                else -> File(outputDir, "frame_%06d.png")
            }
            val requiredEncoder = when (format) { "WEBM" -> "libvpx-vp9"; "MOV" -> "prores_ks"; else -> "png" }
            val encoderCheck = FFmpegKit.executeWithArguments(arrayOf("-hide_banner", "-h", "encoder=$requiredEncoder"))
            if (!ReturnCode.isSuccess(encoderCheck.returnCode)) return@withContext fail("نسخة FFmpeg الحالية لا تحتوي على Encoder المطلوب: $requiredEncoder.")
            val colorKey = "colorkey=0x${key}:" + String.format(Locale.US, "%.3f:%.3f", similarity, blend)
            val args = mutableListOf("-y", "-hide_banner", "-i", source.absolutePath, "-map", "0:v:0")
            if (format == "PNG") {
                args += listOf("-vf", "format=rgba,$colorKey,format=rgba", "-fps_mode", "passthrough", output.absolutePath)
            } else {
                args += listOf("-map", "0:a?")
                val filter = if (format == "WEBM") "format=rgba,$colorKey,format=yuva420p" else "format=rgba,$colorKey,format=yuva444p10le"
                args += listOf("-vf", filter)
                if (format == "WEBM") {
                    args += listOf("-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p", "-crf", crf.toString(), "-b:v", "0", "-deadline", "good", "-cpu-used", cpu.toString(), "-auto-alt-ref", "0", "-metadata:s:v:0", "alpha_mode=1")
                    if (keepAudio) args += listOf("-c:a", "libopus", "-b:a", "128k") else args += "-an"
                } else {
                    args += listOf("-c:v", "prores_ks", "-profile:v", "4", "-pix_fmt", "yuva444p10le", "-alpha_bits", "16", "-qscale:v", "9")
                    if (keepAudio) args += listOf("-c:a", "pcm_s16le") else args += "-an"
                }
                args += output.absolutePath
            }

            val started = System.currentTimeMillis()
            setProgress(workDataOf(KEY_PROGRESS to 0, KEY_STATUS to "جارٍ إزالة اللون وتصدير الملف"))
            val resultCode = executeTracked(args.toTypedArray(), durationMs, started)
            if (isStopped) return@withContext Result.failure(workDataOf(KEY_ERROR to "تم إلغاء التصدير."))
            if (!ReturnCode.isSuccess(resultCode)) {
                return@withContext fail("فشل FFmpeg في المعالجة. جرّب فيديو آخر أو قلّل الدقة.", "FFmpeg return code: $resultCode")
            }

            val pngFrames = if (format == "PNG") outputDir.listFiles()?.filter { it.extension.equals("png", true) }?.sortedBy { it.name }.orEmpty() else emptyList()
            val firstFrame = if (format == "PNG") pngFrames.firstOrNull { containsRealTransparency(it) } ?: pngFrames.firstOrNull() else null
            val previewSource = firstFrame ?: output
            val previewArgs = mutableListOf("-y")
            // FFmpeg's native VP9 decoder drops WebM alpha side data; force libvpx for verification and preview.
            if (format == "WEBM") previewArgs += listOf("-c:v", "libvpx-vp9")
            previewArgs += listOf("-i", previewSource.absolutePath)
            if (format != "PNG" && durationMs > 0) previewArgs += listOf("-ss", String.format(Locale.US, "%.3f", durationMs / 2000.0))
            previewArgs += listOf("-frames:v", "1", preview.absolutePath)
            val previewCode = FFmpegKit.executeWithArguments(previewArgs.toTypedArray())
            if (!ReturnCode.isSuccess(previewCode.returnCode) || !preview.exists()) return@withContext fail("تم التصدير لكن تعذّر إنشاء معاينة الإطار.")

            // Inspect the decoded post-export PNG. It must contain both transparent and visible pixels.
            if (!containsRealTransparency(preview)) return@withContext fail("فشل التحقق: إطار الناتج لا يحتوي على بكسلات شفافة فعلية. راجع لون المفتاح وإعداداته.")

            val savedUris = if (format == "PNG") {
                val frames = outputDir.listFiles()?.filter { it.extension.equals("png", true) }?.sortedBy { it.name }.orEmpty()
                if (frames.isEmpty()) return@withContext fail("لم ينتج FFmpeg أي إطارات PNG.")
                frames.mapIndexed { index, frame -> saveToMediaStore(frame, "image/png", "${base}_${index + 1}.png", "Movies/AlertMaker/PNG Sequence/$base") }
            } else {
                val mime = if (format == "WEBM") "video/webm" else "video/quicktime"
                val relative = if (format == "WEBM") "${Environment.DIRECTORY_MOVIES}/AlertMaker/WebM" else "${Environment.DIRECTORY_MOVIES}/AlertMaker/MOV"
                listOf(saveToMediaStore(output, mime, output.name, relative))
            }
            val previewPath = preview.absolutePath
            setProgress(workDataOf(KEY_PROGRESS to 100, KEY_STATUS to "اكتمل التصدير"))
            Result.success(workDataOf(KEY_OUTPUT_URI to savedUris.first().toString(), KEY_OUTPUT_COUNT to savedUris.size, KEY_PREVIEW_PATH to previewPath, KEY_FORMAT to format, KEY_DURATION to durationMs))
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: SecurityException) {
            fail("لا يمكن الوصول إلى الفيديو. أعد اختياره من الهاتف.", e.javaClass.simpleName)
        } catch (e: Exception) {
            val message = if ((e.message ?: "").contains("space", ignoreCase = true) || (e.message ?: "").contains("storage", ignoreCase = true)) "المساحة غير كافية لحفظ الملف الناتج." else "حدث خطأ أثناء التصدير: ${e.message ?: "خطأ غير معروف"}"
            fail(message, e.javaClass.simpleName)
        } finally {
            workDir.deleteRecursively()
        }
    }

    private suspend fun executeTracked(args: Array<String>, durationMs: Long, started: Long): ReturnCode? {
        val completed = CompletableDeferred<ReturnCode?>()
        val session = FFmpegKit.executeWithArgumentsAsync(args, { s ->
            if (!completed.isCompleted) completed.complete(s.returnCode)
        }, { log ->
            val line = log.message ?: ""
            val match = Regex("time=(\\d{2}):(\\d{2}):(\\d{2})\\.(\\d+)").find(line)
            if (match != null && durationMs > 0) {
                val (h, m, sec, fraction) = match.destructured
                val current = h.toLong() * 3_600_000 + m.toLong() * 60_000 + sec.toLong() * 1_000 + (fraction.take(3).padEnd(3, '0').toLong())
                val percent = ((current * 100) / durationMs).toInt().coerceIn(0, 99)
                lastProgress.set(percent)
                val elapsedSeconds = ((System.currentTimeMillis() - started) / 1000).toInt()
                val etaSeconds = if (percent >= 3) (elapsedSeconds * (100 - percent) / percent).coerceAtLeast(0) else -1
                setProgressAsync(workDataOf(KEY_PROGRESS to percent, KEY_STATUS to "جارٍ المعالجة • ${percent}%", KEY_ELAPSED to elapsedSeconds, KEY_ETA to etaSeconds))
            }
        }, { stats ->
            if (durationMs > 0) {
                val percent = ((stats.time * 100) / durationMs).toInt().coerceIn(0, 99)
                lastProgress.set(percent)
                val elapsedSeconds = ((System.currentTimeMillis() - started) / 1000).toInt()
                val etaSeconds = if (percent >= 3) (elapsedSeconds * (100 - percent) / percent).coerceAtLeast(0) else -1
                setProgressAsync(workDataOf(KEY_PROGRESS to percent, KEY_STATUS to "جارٍ المعالجة • ${percent}%", KEY_ELAPSED to elapsedSeconds, KEY_ETA to etaSeconds))
            }
        })
        activeSession.set(session.sessionId)
        setProgress(workDataOf(KEY_PROGRESS to 1, KEY_STATUS to "بدأت المعالجة"))
        try {
            while (!completed.isCompleted) {
                if (isStopped) {
                    FFmpegKit.cancel(session.sessionId)
                    break
                }
                val elapsed = System.currentTimeMillis() - started
                val pct = lastProgress.get()
                val eta = if (pct >= 3) ((elapsed * (100 - pct)) / pct / 1000).coerceAtLeast(0) else -1
                setForeground(createForeground(if (eta >= 0) "جارٍ التصدير • متبقٍ نحو ${eta}ث" else "جارٍ تصدير الفيديو", pct))
                kotlinx.coroutines.delay(900)
            }
            return completed.await()
        } finally {
            if (!completed.isCompleted) FFmpegKit.cancel(session.sessionId)
            activeSession.set(-1)
        }
    }

    private fun readDuration(file: File): Long = try {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(file.absolutePath)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } finally { retriever.release() }
    } catch (_: Exception) { 0L }

    private fun containsRealTransparency(file: File): Boolean {
        return try {
            val bitmap = android.graphics.BitmapFactory.decodeFile(file.absolutePath) ?: return false
            try {
                var transparent = false
                var visible = false
                val stepX = (bitmap.width / 160).coerceAtLeast(1)
                val stepY = (bitmap.height / 160).coerceAtLeast(1)
                var y = 0
                while (y < bitmap.height && !(transparent && visible)) {
                    var x = 0
                    while (x < bitmap.width && !(transparent && visible)) {
                        val alpha = android.graphics.Color.alpha(bitmap.getPixel(x, y))
                        if (alpha < 245) transparent = true
                        if (alpha > 10) visible = true
                        x += stepX
                    }
                    y += stepY
                }
                transparent && visible
            } finally { bitmap.recycle() }
        } catch (_: Exception) { false }
    }

    private fun saveToMediaStore(file: File, mime: String, name: String, relativePath: String): Uri {
        val collection = if (mime.startsWith("video")) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            } else {
                val folder = File(applicationContext.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "AlertMaker/${relativePath.substringAfter("AlertMaker/")}").apply { mkdirs() }
                put(MediaStore.MediaColumns.DATA, File(folder, name).absolutePath)
            }
        }
        val uri = applicationContext.contentResolver.insert(collection, values) ?: error("تعذّر إنشاء ملف في MediaStore")
        try {
            applicationContext.contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } } ?: error("تعذّرت كتابة الملف")
            if (Build.VERSION.SDK_INT >= 29) {
                values.clear(); values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                applicationContext.contentResolver.update(uri, values, null, null)
            }
            return uri
        } catch (e: Exception) {
            applicationContext.contentResolver.delete(uri, null, null)
            throw e
        }
    }

    private suspend fun fail(message: String, technical: String = ""): Result = Result.failure(workDataOf(KEY_ERROR to message, KEY_TECHNICAL to technical.take(600)))

    private fun createForeground(message: String, progress: Int): ForegroundInfo {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel(channelId, "AlertMaker export", NotificationManager.IMPORTANCE_LOW))
        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("AlertMaker")
            .setContentText(message)
            .setOngoing(true)
            .setProgress(100, progress.coerceIn(0, 100), progress == 0)
            .build()
        return if (Build.VERSION.SDK_INT >= 29) ForegroundInfo(notificationId, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else ForegroundInfo(notificationId, notification)
    }

    companion object {
        const val KEY_URI = "uri"; const val KEY_FORMAT = "format"; const val KEY_COLOR = "color"
        const val KEY_SIMILARITY = "similarity"; const val KEY_BLEND = "blend"; const val KEY_CRF = "crf"
        const val KEY_CPU = "cpu"; const val KEY_AUDIO = "audio"; const val KEY_PROGRESS = "progress"
        const val KEY_STATUS = "status"; const val KEY_ELAPSED = "elapsed"; const val KEY_ETA = "eta"; const val KEY_ERROR = "error"; const val KEY_TECHNICAL = "technical"
        const val KEY_OUTPUT_URI = "output_uri"; const val KEY_OUTPUT_COUNT = "output_count"
        const val KEY_PREVIEW_PATH = "preview_path"; const val KEY_DURATION = "duration"
    }
}
