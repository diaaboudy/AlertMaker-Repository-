# Media pipeline smoke-test record

These checks were run in the current build container with desktop FFmpeg 7.1.5 (not the Android AAR):

- `libvpx-vp9`, `prores_ks`, and `png` encoder help/preflight commands returned success.
- A generated 320×180 black-background clip with a white foreground box was processed with the app's WebM command. `ffprobe` reported `codec_name=vp9` and `TAG:ALPHA_MODE=1`.
- Important decoder caveat: the native FFmpeg VP9 decoder rendered that WebM preview fully opaque. Re-decoding with `-c:v libvpx-vp9` before `-i` preserved alpha; the decoded PNG alpha range was 0–255, with transparent background and opaque subject pixels. The Android worker uses this forced decoder for its post-export preview/check.
- The ProRes command produced `codec_name=prores`, `profile=4444`, and `pix_fmt=yuva444p12le`; its decoded PNG alpha range was 0–255.
- The PNG-sequence command produced RGBA PNGs with alpha range 0–255.

This is a command-line pipeline smoke test only. It does not substitute for a clean Android Gradle build, testing the pinned Android AAR on-device, or testing the resulting media in the user's OBS/TikTok LIVE Studio versions. The GitHub Actions workflow performs the Android build and unit tests after the project is committed.
